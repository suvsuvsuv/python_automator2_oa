# -*- coding: utf-8 -*-
# #coding=utf-8 要写在文件最开始！ 长记性了！ 谢谢大家的帮助！
from phoneUtil import Adb
from QQMail import *
import outlook
from outlook import *
import time
import random
import string

def check_outlook():
    mail = outlook.Outlook()
    mail.login('wsunca@hotmail.com', 'eliza1211!')
    mail.inbox()
    # print mail.unreadToday() # 必须判断null
    ids = mail.unreadIdsToday()
    for id in ids:
        if id is None or id == '':
            continue
        mail.getEmail(id)
        subject = mail.mailsubject()
        if subject == None:
            return ''
        subject = subject.lower()
        if subject.startswith('mobileoa'):  #subject.find('mobileoa') >= 0:
            ll = subject.split(':')
            if len(ll) > 1:
                cmd = ll[1]
            else:
                cmd = ''





                
            #cmd = mail.mailbody()
            return cmd

def send_okmail_toqq():
    #send_mail('368029724', 'zrksshkomyrpcaea', '368029724@qq.com', 'auto checkin', 'i am alive')
    #send_mail('1043990501', 'lkrexkrvckvbbdda', '1043990501@qq.com', 'auto checkin: I_am_ok', '')
    timeAll = show_time()
    send_email('I_m_ok', timeAll)


def send_resultmail_toqq(cmd):
    if cmd.startswith('checkin'):
        subject = 'checkin'
    else:
        subject = 'login'
    filename = 'result.jpg'
    send_email(cmd, '', filename)

def process_checkin(cmd):
    isCheckin = False
    if cmd.startswith('checkin'):
        isCheckin = True
    Adb.unlock_phone()
    Adb.press_home()
    #Adb.clean_result()
    Adb.mobileoa(isCheckin)
    Adb.press_home()
    Adb.pull_result()
    time.sleep(1) #delay 1s
    send_resultmail_toqq(cmd)

def add_time(timeStr):
    timeList.append(timeStr)

def get_time():
    if len(timeList) > 0:
        timeStr = timeList[0]
        del timeList[0]
    else:
        timeStr = None
    return timeStr

def show_time():
    timeAll = ''
    for str in timeList:
        timeAll = timeAll+ str + "    "
    return timeAll

default_morning = '08:40'
default_evening = '18:30'
def generateTime(min):
    min = min + random.randint(0, 9)
    return str(min)

def create_time_list():
    del timeList[:]
    ll = default_morning.split(':')
    min = string.atoi(ll[1])
    str = ll[0] +':' + generateTime(min)
    add_time(str)
    ll = default_evening.split(':')
    min = string.atoi(ll[1])
    str = ll[0] + ':'+ generateTime(min)
    add_time(str)
    print(show_time())

def check_timeList(mytime):
    #print mytime
    strTime = mytime
    if len(timeList) > 0:
        for time in timeList:
            if time == strTime:
                timeList.remove(time) # 3.删除指定值的元素
                return 'checkin'
                '''print 'auto checkin: ' + strTime
                process_checkin('checkin')
                print '---------------------'
                '''


timeList = []

def main():
    print('robot is runing...')

    '''add_time("08:35")
    add_time("18:43")
    print show_time()
    send_okmail_toqq()
    print get_time()
    print get_time()
    print get_time()
    '''

    '''create_time_list()
    print show_time()
    mydate = datetime.datetime.now()
    check_timeList(mydate.strftime("%H:%M"))
    '''
    # process_checkin('login')

    day = -1
    while True:
        cmd = None
        mydate = datetime.datetime.now()
        strShortTime = mydate.strftime("%H:%M")
        nowDay = mydate.day
        if (day != nowDay):
            day = nowDay
            # create_time_list()

        try:
            cmd = imap4("imap.qq.com", 993, IMAP_USER, IMAP_PWD, True)
            # check_outlook()
        except:
            print("something is wrong with qq....")
            time.sleep(5)
            continue
        if cmd is None:
            cmd = check_timeList(strShortTime)
        if cmd is not None:
            strTime = mydate.strftime("%Y-%m-%d %H:%M:%S")
            if cmd.startswith('checkin'):
                print('check in: ' + strTime)
                process_checkin(cmd)
                print('---------------------')
            elif cmd.startswith('login'):
                print('log in: ' + strTime)
                process_checkin(cmd)
                print('---------------------')
            elif cmd.startswith('auto'):
                print('create time: ' + strTime)
                create_time_list()
                send_okmail_toqq()
                print('---------------------')
            else:
                print ('send ok mail: ' + strTime)
                send_okmail_toqq()
                print ('---------------------')
                # print cmd
        time.sleep(5)

    '''mail = outlook.Outlook()
    mail.login('wsunca@hotmail.com', 'suny1211!')
    mail.sendEmail('368029724@qq.com', 'test', 'message body')
    '''

def main1():
    print('robot is runing...')
    day = -1
    add_time('18:35')
    print(show_time())
    while True:
        cmd = None
        mydate = datetime.datetime.now()
        strShortTime = mydate.strftime("%H:%M")

        cmd = check_timeList(strShortTime)
        if cmd is not None:
            strTime = mydate.strftime("%Y-%m-%d %H:%M:%S")
            if cmd.startswith('checkin'):
                print('check in: ' + strTime)
                process_checkin(cmd)
                print('---------------------')
                break
        time.sleep(5)
    print('robot quitted...')

if __name__ == "__main__":
    main1() #main()


