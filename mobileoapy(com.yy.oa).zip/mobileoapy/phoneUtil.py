import os
import subprocess

isXiaoMi = False

# https://rustfisher.github.io/2017/07/05/Python_note/Python-adb/
class Adb(object):
    """ Provides some adb methods """

    @staticmethod
    def pull_sd_dcim(device, target_dir='E:/files'):
        """ Pull DCIM files from device """
        print( "Pulling files")
        des_path = os.path.join(target_dir, device)
        if not os.path.exists(des_path):
            os.makedirs(des_path)
        print(des_path)
        cmd = "adb pull /sdcard/DCIM/ " + des_path
        result = subprocess.Popen(cmd, shell=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE).communicate()
        print(result)
        print("Finish!")
        return des_path

    @staticmethod
    def unlock_phone():
        cmd = "adb shell input keyevent 26"
        result = subprocess.Popen(cmd, shell=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE).communicate()[0]

        cmd = "adb shell input swipe 500 1000 500 50"
        if isXiaoMi:
            cmd = "adb shell input swipe 344 934 344 1156"
        subprocess.Popen(cmd, shell=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE).communicate()[0]
        print("turn on phone")

    @staticmethod
    def press_home():
        cmd = "adb shell input keyevent 3"
        result = subprocess.Popen(cmd, shell=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE).communicate()[0]
        print("press home")

    @staticmethod
    def mobileoa(ischeckin):
        if ischeckin :
            cmd = "adb shell am instrument -e class com.yy.oa.MainActivityTest#testALogin,com.yy.oa.MainActivityTest#testBCheckIn -w com.yy.oa.test/android.test.InstrumentationTestRunner"
        else:
            cmd = "adb shell am instrument -e class com.yy.oa.MainActivityTest#testALogin -w com.yy.oa.test/android.test.InstrumentationTestRunner"
        subprocess.Popen(cmd, shell=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE).communicate()[0]
        print("mobileoa")

    @staticmethod
    def pull_result():
        cmd = "adb pull /sdcard/Robotium-Screenshots/result.jpg"
        subprocess.Popen(cmd, shell=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE).communicate()[0]
        print("pull_result")

    @staticmethod
    def clean_result():
        cmd = "adb shell rm /sdcard/Robotium-Screenshots/result.jpg"
        subprocess.Popen(cmd, shell=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE).communicate()[0]
        print("clean_result")

    @staticmethod
    def some_adb_cmd():
        p = subprocess.Popen('adb shell cd sdcard&&ls&&cd ../sys&&ls',
                             stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        return_code = p.poll()
        while return_code is None:
            line = p.stdout.readline()
            return_code = p.poll()
            line = line.strip()
            if line:
                print(line)
        print("Done")
